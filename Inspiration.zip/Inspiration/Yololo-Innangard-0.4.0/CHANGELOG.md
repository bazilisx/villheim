# Changelog

## 0.4.0

**Sea trade**

- New: trade by sea between two settlements on the coast. In the Trade screen, under "Sea trade", chart a sea way to another settlement; the chart keeps to water deep enough for a keel, stays off the shore and is drawn on the map as a dashed blue line. Moor a Karve, a Longship or a Drakkar near the Frithstone (rafts stay with the fishermen) and press "Send ship". The ship loads from the trade chest, sails the sea way, unloads into the far settlement's trade chest and sails back to the berth it left
- A ship carries thirty goods for each slot of its hold. It sails at a steady pace whatever the wind, and runs on while nobody is near: where somebody can see it, it sails the line with its sail set; where nobody can, it is moved along the line so it is where the voyage says when somebody comes
- A ship on a voyage cannot be steered. Its helm says so, and "Call ship back" turns it for home with its load. A ship waits while a player stands on its deck, and fishermen and the boat keeper leave it alone
- New: shipments further afield. Roads and sea ways now form one network, and "Shipments further afield" in the Trade screen lists every settlement more than one leg away with the quickest chain of roads and sea ways to it. Press "Ship goods" and the load goes by road to a harbour, by ship to another and on by road from there. A settlement on the way keeps the load on its stone rather than in its chest and hands it to its next carrier as soon as one is free - the caravan on the next road, or a free ship moored in its harbour, even with nobody there. A load bigger than the next carrier goes on in parts, and the Trade screen says what is waiting to pass through. Only the far end needs a trade chest
- Both ends of a sea way are found again after the world is reloaded, the same way a road's are, and a voyage finds its ship again by a mark written on the hull

**Combat**

- An archer with no shot at something just outside arm's length no longer flickers on the spot. With the shot blocked it closed half the distance, which put it inside the range it backs away from, and once it had backed out it still had no shot and closed again. It now never walks into that range for a shot: it circles round the target at the same distance to a spot it can actually shoot from, or holds outside its reach, and gives the target up after twenty seconds without a shot however often it moved. Followers set to bows only were the ones that showed it most

**Morale**

- Residents are no longer charged for a night nobody was there for. A resident only lives while a player is near, so when everyone spent the night away from the village - out exploring, or asleep somewhere else - the residents woke the next morning "short of sleep" and "without supper" for a night they never lived. Such a night now reads "The night passed with nobody nearby" and costs nothing

## 0.3.9

**Guards**

- New piece: the Watch Post (Hammer, the Innangard row), an iron standing torch that burns without fuel. Place it on a tower or a wall walk with stairs or a ramp up to it. A guard with a bow and arrows takes it for its whole shift and shoots what it can see from there, during raids too. It does not come down to chase, back away or walk round, and it lets a target it has no shot at go for a few seconds instead of staring at it. It only leaves the post when something climbs up to it, when it runs out of arrows or when you set it to fight with a blade, and goes back up after the fight. One guard to each post; other guards keep walking their rounds. Residents do not climb ladders
- A guard standing its watch post is no longer carried off by the stuck rescue, and a guard on a post set to "bow, then blade" no longer draws its blade for something at the foot of the tower

**Combat**

- Archers no longer flicker in place when an enemy gets close and the shot is blocked. "Stepping back for a lane" walked them towards the enemy, and the shot came back after a step, so they went back and forth on the spot. They now back away the same way as any archer that is too close, and keep going a little past the danger distance before they turn to shoot
- An archer whose target died while it was backing away no longer starts the next close fight as "cornered"

**Clans**

- The clan event list is now translated. Its entries never matched their translations and always showed in English, and Jotunn logged a warning for each of them at game start

## 0.3.8

**Languages**

- Innangard speaks your language. The whole mod - panels, settings, guide, Hugin and everything the residents say - is now translated into Turkish, Spanish, French, German, Italian, Brazilian Portuguese, Russian, Polish, Ukrainian, Simplified and Traditional Chinese, Japanese and Korean. It follows the language you set in Valheim, and items, creatures and biomes use the game's own names

**Sleep and morale**

- On a dedicated server, residents now get the night when a player sleeps it away. The server skips the night, but only the player who looks after a resident can write down its sleep, so every resident woke "short of sleep" and lost morale every day
- Sleeping in the afternoon (Valheim allows it from noon, and longer-day mods make it the usual time) no longer charges residents for a missed night. The skipped night was written to the day that was ending instead of the morning after
- Supper missed because the evening was slept away no longer costs morale. Residents show "Slept the evening away with the rest" instead

**Combat**

- Guards no longer stand at the palisade facing an enemy on the other side. A blade does not pass a wall, so they now go out through a clear gate to meet it, and hold or fall back when no gate can be opened

**Settlements**

- "Send to another Frithstone" could say you had raised no other Frithstone for some residents. It now also lists the settlements of whoever built the resident's own stone, and the move puts the resident's owner right. If the list is still empty, the log says why

## 0.3.7

Bug fix.

- Looting a resident's grave no longer gives Valheim's Corpse Run boost (+150 carry weight for a while). A resident's grave belongs to the player so they can open it, and the game took emptying it as the player recovering their own body. Your own grave still gives the boost

## 0.3.6

**Clans are live.** Found a clan, take in other players with Viking ranks, link everyone's
villages, make alliances, call each other to defend, and - on servers that turn it on with
`inn.clan.pvp on` - go to war and raid enemy villages. Below are the fixes that went in
before release, together with bug fixes from player reports.

**Residents and gear**

- "Take better gear from chests" switched off now really means it. A Caretaker carrying armour and weapons between chests used to put them on; carried loads are never worn or wielded now
- In multiplayer, a resident could not use a warded chest when the player whose machine ran it was not on the ward. Chests are now checked against the settlement owner's ward access, so food in the settlement's own chests is not refused

**Caretaker**

- A Caretaker no longer empties chests into each other. In a chest set to "What it already holds", a single stack among others counted as misplaced and went off to an empty chest, which set off the next move, and the next. Such an item now only moves to a chest that actually asks for it: a chest set by hand or by kind, a chest that already holds mostly that item, or a leftovers chest. It never moves to a merely empty chest

**Combat and followers**

- Residents no longer freeze on "Falling back to defensible ground" against leeches and other swimmers. They fight a swimmer within reach from the shore and give up on one out of reach after a few seconds
- "Bow, then blade" fighters switch back to the bow once the enemy is 9 m away again, instead of keeping the blade for the rest of the fight
- Archers take on attackers at bow range (20 m), so they no longer start every fight too close and back away
- Two or more followers each keep their own place in the formation instead of standing inside each other

**Morale**

- The settings tab shows server settings as the server applies them, and only an admin can change them. Before, a non-admin could switch "Unhappy residents may leave" off on their own screen while the server kept it on
- With leaving switched off, the morale warning no longer says a resident will walk out in N days
- A resident walking out is always written to the log, together with the setting as that machine sees it

**Clans**

- Settlement owners can reach the Villages group again, to ask to join a clan, cancel the request or leave. It was hidden at every unlinked village, so no village could be linked
- A member removed from a clan has their villages unlinked, as when leaving
- Approving a membership application goes through the server, so one player can no longer end up in two clans
- Clans saved by the previous version can be recovered again
- Only the Jarl sees the buttons to approve or decline applications

**Raids**

- Settlement guards now fight raiders at any distance from the clans' Frithstones. Before, they only saw a raid when the attacking clan's stone was loaded nearby, and only fought back once hit
- Raiders and defenders can hurt each other at the raided village however far it is from either clan's stone. Players who join or leave the war during a raid are picked up straight away
- Every online member of the defending clan sees "Fjellby is under attack!" in yellow when a raid starts

## 0.3.5

**Work areas on no-map worlds**

- Open Work Areas from the Frithstone to use Valheim's own large map, even when the world has no map enabled. The map remains centered on the Frithstone and uses the game's native pan, zoom, pins and map display.
- Closing the work-area map restores the world's no-map restriction. Work-area drawing and storage remain attached to that Frithstone.
- Reduced the work done to draw circles and straight lines in the remaining map-based editors, which makes those canvases lighter to redraw.

## 0.3.4

Chest sorting fix.

**Chest sorting**

- Barley flour, oat flour, eggs and 22 other items were invisible to chest sorting: no chest would take them, the Caretaker never moved them, and pinning one said it could not be sorted. Valheim files them as Misc rather than as a material, and sorting only knew materials, food, trophies, fish, ammunition and equipment. They are sorted now
- Flour, bread dough, the uncooked dishes and eggs sort with Food, so a chest set to Food takes them beside what they become. Dough and the uncooked dishes used to sort with Materials; in an existing settlement the Caretaker carries them to a Food chest if there is one
- Keys, saddles, dragon tears, ancient seeds, barrel hoops and the other odd items sort under Other, so a chest set to Other, or one set to take whatever no other chest wants, holds them

## 0.3.3

Combat, navigation and storage fixes.

**Combat and pathfinding**

- Combat chases no longer refresh just because a moving target shifted by a few centimetres. Residents keep following the same route until the target has moved far enough to justify a new one
- Melee residents hold the shoreline when their target is swimming; residents who enter water leave for dry ground before resuming combat
- Path searches and doorway approach checks yield across frames within measured time budgets, reducing combat and navigation hitches in built up areas

**Fishing and storage**

- The fishing rod is equipped only while the fisherman is actively casting and is released when the cast ends
- Caretakers can store raw fish already carried by a resident after its trade changes, instead of leaving those stacks in the pack indefinitely

**Settlement roster**

- A resident whose own stone had gone, and whose home lay within the rehome radius of
  another of your stones, was counted as that stone's resident but shown in neither the
  Settlers list nor among the sleeping until it died and came back. The panel asked only
  for a home within six metres of the stone, while the headcount also took in a resident
  the stone would adopt; the loaded and the unloaded are now judged by the one rule, so
  it is listed at once. A loaded resident you may not manage is still kept off the lists
  on purpose, rather than being shown as dead with no trades to give it

## 0.3.1

The Smith is handed out.

- The Smith is offered from the panel like every other craft. It makes things at the
  settlement's stations up to the Stock tab's targets, from the founder's recipes copied
  onto the Frithstone; mends worn things it finds in the chests and its own tools; keeps
  arrows in the chests for every resident with a bow; and dresses bare residents in
  leather or rags. Residents hand their broken tools in at a chest while there is one
- Work/OfferUnfinishedCrafts now only concerns the Miner

## 0.3.0

Residents that get where they are going.

**Navigation**

- Residents climb step ladders and come back down them, one ladder at a time - a stack
  of them up the side of a tower included. Valheim's own ladder is climbed as before
- Long routes are no longer cut short. A search taken in turns may run up to twice as
  long as a search taken in one frame, so a chest on a terrace forty metres off and
  twelve metres down is reached, instead of approached on partial routes with a stall at
  every wall on the way
- A shut door is a wall to the planner and is handed to the door hunt, which knows how to
  open it. The hunt remembers the door sides it has judged and the ones it found
  unreachable, looks a storey up and down for terraces, and no longer calls itself
  "pending" when it has merely run out of time
- An errand outside the palisade, or behind it, goes out through the outer gate.
  Portals are never walked into
- A resident standing in less room than it takes up steps out sideways, never through a
  wall; one that has fallen into a pit is rescued; a guard keeps walkers off ledges
- The planner never chooses the ground under a floor slab, no longer refuses a route
  for a sweep that starts inside something or goes downhill, and gives straightening a
  time budget of its own
- The edge of a work area is measured flat, the way the area itself is, so a tree on a
  slope is no longer refused by the fence that let the farmer in
- The standing places round a chest or a station get an outer ring when the near ones
  are all refused
- A resident whose searches keep failing waits longer between tries, and one that has
  failed six times in twenty seconds leaves the planner alone for a few seconds while
  the ordinary steering and the door opener carry on
- A winding path is given more patience before its walker is called stuck

**Meals**

- A chest a resident could not walk to is passed over for the next few looks instead of
  being chosen again every time; the nearer chest with the same food wins; and when every
  chest with food in it has failed, the resident tries again rather than go hungry
- Raw carrots, onions and turnips are not eaten
- Favourite foods are retired. A dish of several things is preferred and is worth
  morale, and the cook makes them at the cauldron and keeps its fire in
- Seed crops are kept back from meals

**Gear by trade**

- Axes and pickaxes are only taken by the trades that swing them; everyone carries one
  melee weapon; hunters go light and ranged, guards and followers heavy and best;
  civilians are capped (Settler/CivilianWeaponMaxDamage) and carry no shield; heavy
  armour is only ever a fallback
- Gear outside a resident's class is put back, stray tools are returned to the chests,
  and the cultivator is held only while it is in use
- Residents hand broken tools in at a chest while there is a Smith to mend them

**Work**

- The work area reaches from the Frithstone to the edge of the simulated world
  (Work/WorkAreaRadius) plus whatever circles you draw; the keep-out circles the
  settlement learns on its own no longer fence off work
- Lumberjacks can be set to replant (Work/LumberjackReplant), and clear felled timber
  before felling more
- Crafting is done in batches; hunters loot their kills; litter is picked up, arrows
  included; a full chest is handled instead of stood in front of; graves can be opened;
  the caretaker surveys the settlement on a clock
- Farmer: the seed crop is grown to the field's free room, a reserve is planted when the
  line is stranded, and a field keeps to its own side of the palisade
- A player's tombstone is never taken for a resident's grave
- Anything that keeps failing is set aside for longer each time

**Smith**

- A new craft, held back behind Work/OfferUnfinishedCrafts with the Miner until it has
  been watched through a full session
- Makes things at the settlement's stations up to the Stock tab's targets, from the
  founder's recipes copied onto the Frithstone
- Mends worn things it finds in the chests and its own tools, keeps
  Work/ArrowsPerArcher arrows in the chests for every resident with a bow
  (Work/SmithArrow), and dresses bare residents in leather or rags

**Combat and hunting**

- A resident's blow on an ownerless creature, tree, log, bush or rock claims it first,
  so the damage lands - far from any player the game was dropping it
- Archers: arrows fall under gravity when the straight shot is blocked, point-blank
  shots leave from the right place, the target's own ground is not an obstacle, and prey
  inside the hunting grounds is exempt from the leash
- The rescue watch measures fights as well as walks

**Roads**

- The road line is drawn on the ground near you, built stretches show green, and each
  row is judged built on its own; the survey leaves by the gate and snaps to hoed ground;
  a rebuilt Frithstone keeps its settlement code

**Beds**

- A resident takes its own bed back from up to 150 metres away

**Builder**

- Planned pieces carry no trigger volumes, which were blocking workbench placement

**Performance**

- Each resident's per-frame work is a tenth of what it was: the animator's parameters,
  the look, the name and several saved fields were being read again every frame
- The planner answers a repeated navmesh question from memory for a second, keeps a
  resident's last few routes for a few seconds, and never lets the resident holding a
  frame's turn run several searches in it
- Navigation tracing costs nothing while it is off
- Measured with ten residents: the mod's share of a frame fell from about eleven
  milliseconds to about one, and the garbage it makes from eight megabytes a second to
  under two

**Console**

- inn.perf [seconds] measures where the mod's frame time goes and reports it
- inn.net logs network queues, resident ownership and replicated data sizes
- inn.navtest route/ground/segment/passage checks a route or a piece of ground without
  moving anyone; inn.navtest on/off turns navigation tracing on or off for the session
- inn.cloudrestore registers a folder of world files with Steam Cloud

## 0.2.1

A fix on top of 0.2.0.

- Fixed a hitch about once a minute while a farmer had nothing to plant. A report meant
  only for the verbose log was searching every field for somewhere to sow whether the log
  was on or not - the same search whose once-a-second repeat was the 0.1.9 farmer stutter

## 0.2.0

What the players reported, what they asked for, and a settlement that tidies itself.

**Chests**

- Look at a chest and the line under it says what it is for - "For: Stone, Wood ... (+3)",
  "Takes more of: Honey", "Empty - takes anything" - and "(full)" when it is
- Chests can be named, at the top of their window. The name is shown instead of the rule
  and as the chest window's title
- In the chest window: "Keep what's inside here" adds everything inside to the chest's
  list, and Shift+right-click pins a kind of thing to the chest or lets it go
- Green and red frames on the slots of a chest that was told what it is for: green belongs,
  red will be carried away. A button in the chest window, or the settings, turns them off
- Every item's tooltip ends with where it belongs in the settlement
- Copy what a chest is for, and paste it onto the next
- A new answer to what a chest is for: "Whatever no other chest wants". Odds and ends go
  there instead of into the first empty chest, and anything another chest asks for is
  carried out to it
- "A list I choose" on a chest that goes by its contents starts with what is inside
- "No craft brings work here" no longer hides a chest from the settlement. Nothing is put
  away in it, as the window always said, but everyone can take from it and what is in it
  is counted
- A chest told what it holds is not a home for anything else, and a chest that refuses
  something is no longer asked again every tick (the "can't be stored" spam)

**Caretakers**

- The chests and the floor come first and the furnaces after. What is picked up off the
  floor goes to a chest before the next job; fires and furnaces may be fed a little late,
  but never left for more than about five minutes
- Sorting rounds deliver everything they collect. The first thing taken was dropped from
  the round as soon as the caretaker went on to the next chest, and carried back
- A round that hits a chest it cannot reach skips it and goes on with the rest
- A load carried in several stacks goes into a chest in one visit
- Rounds stop at six chests, and stop collecting after 45 seconds when something else is
  waiting
- A caretaker no longer fills the odds-and-ends chest with something another chest wants
  just because that chest was briefly out of reach
- Two caretakers can work one chest at once

**Farmers**

- The Farmer does not hoe: it plants only on ground you have cultivated. The Guide says so
- A farmer takes ten seed at a time and puts back what it cannot plant
- When seed is short the farmer says why: waiting for the seed crop to ripen, or nothing in
  the chests to grow more seed from - and a field left alone because its crop has reached
  its stock target says that too
- Two farmers on one field take a ripe crop each
- A deposit threshold of 0 no longer means a trip per crop; field assignments survive a
  reload; modded cultivators are recognised; crop pairs are offered when either half has
  seed
- A farmer carrying the harvest home keeps walking until the pack is empty

**Guards and defence**

- Guards sharing a route no longer walk it shoulder to shoulder: each starts somewhere
  different, waits a different while, and now and then turns back or skips a post
- Posts with a wall between them and the stone are left out of the watch ring, and a post
  a guard cannot get nearer to is skipped
- Called to a spot during an alert, guards spread out round it
- One creature no longer puts the whole settlement on alert: it takes three inside the
  walls, a blow to the Frithstone, a guard falling or a raid. Deer, Dverger and penned
  animals are not counted
- A hunter no longer runs back to defend the settlement from a deer

**Residents**

- Spare time: residents with nothing to do sit a while, stroll to a quiet corner and
  linger, instead of crowding round the Frithstone. Idle residents prefer a quiet chair
- Conversations: residents meeting each other may stop and talk - three lines between
  two people, about what happened to them yesterday, their trade, their nature, the
  weather, the founder and the night
- Supper: residents walk to a free seat rather than eating standing up beside it
- Residents put the gear they replace back in a chest, and wear the best piece of each
  kind they carry
- A resident choosing between two equally good chests keeps to the one it picked, instead
  of turning back every few steps
- Residents on the floor below something no longer count as having arrived at it, and
  nobody climbs into a bed on the floor above through the ceiling
- Workbenches, kilns, smelters, fires and cooking stations get a proper place to stand, the
  way chests do; tools are no longer mended through the floor
- A door is taken even when nothing shows the way on from it, if the straight line is
  through a wall; doorways with a step or a porch are walked through while open
- Residents keep their skills and trait through death, favourite foods, walk through each
  other without stepping aside, and let go of targets they get nowhere with

**Players can**

- Open every setting from the pause menu: Esc, then Innangard. Everyday settings first, the
  rest under Advanced, with a search box, a Default button on anything changed, and the
  allowed range of every number
- Read the Guide tab on the panel: what the mod does, one topic at a time
- Ctrl+Use a resident and then a bed to give it that bed, a tree to keep it standing, or a
  fire, bench or smelter to keep the settlement off it
- Rebind Shift+Use ([Controls] InteractModifier), and optionally use that key alone
  ([Controls] InteractModifierAlone, off by default)
- Build the trade chest from the start of the game
- Hear from Hugin about fields, hunting, the tree you keep, guard rounds, beds, a
  resident's nature, favourite food, visitors and a second settlement

**Multiplayer and performance**

- Ownership is asked for and handed over, never taken from a player; stations no longer
  swap owner back and forth, and a dedicated server leaves ownerless things to the player
  beside them
- Trade routes are only given up by the server
- Long route searches are spread over several frames instead of stopping the game
  ([Navigation] SpreadPathSearches), and take turns fairly
- The mod keeps a running list of chests, doors, trees and residents instead of searching
  the whole scene ([Debug] SceneRegistry, turn off only if residents stop seeing something)
- Farmers check each field once and share it, instead of each searching the world for ripe
  crops

**Console**

- inn.debug on unlocks three test commands for the session: inn.selftest checks the chest
  rules and puts everything back, inn.test.caretaker sets up a sorting job beside you and
  reports how the caretakers did, and inn.reach says whether residents can stand somewhere
  and use the chest you are looking at

## 0.1.9

Fixes on top of 0.1.8.

- Fixed a stutter that happened whenever a farmer had nothing left to plant. It was
  checking every spot in its fields again every second; now it waits until a crop has
  been harvested and there is room to sow
- The chest sorting window shows its list of items again. When the private chest got a
  section of its own the window stayed the same height, and the list was squeezed to
  nothing under the search box. It always keeps room for a few rows now
- A caretaker picking things up off the ground no longer runs off to a chair and back
  every twenty seconds
- A cook with a full larder says so. It said "No raw food in the frith chests" while
  standing beside chests of raw meat, when the real reason was that enough was already
  cooked for everyone
- A hunter walks over to its kill and picks up the meat, including game it shot just
  outside its hunting grounds, and moves on as soon as the kill is cleared instead of
  standing over empty ground
- A hunter that loses track of an animal no longer waits for meat from something it
  never killed
- Guards and hunters keep hold of their weapons. A resident's pack was being read back
  every few seconds, and a bow already in hand stopped counting as held
- A resident that cannot get to a seat at supper eats where it stands, instead of trying
  one bench after another across the settlement
- Residents no longer walk up a roof heading straight for something on the far side of a
  house
- Routes keep out of the shallows along a sea wall when there is a way round on dry land

## 0.1.8

Residents who work like they live here.

This is the last update for about three weeks, so it gathers up everything reported
since 0.1.7.

**Companions and fighting**

- Companions no longer hit like fully trained fighters from the day they arrive. A
  resident's damage roll was the one the game uses for creatures, which is as good as a
  player who has maxed the weapon - archers were four-shotting trolls with a second bow
  and wooden arrows, and a first swing staggered almost anything. Damage now follows the
  resident's own fighting skill: a newcomer hits like somebody who has held a weapon
  before, and gets stronger as it levels

**Hunters**

- A hunter carries its game home when the pack is full or night falls, like every other
  trade, instead of walking each kill back to the chest by the Frithstone
- A hunter only goes back for arrows when it is actually running low, and still takes a
  full quiver when it does. Loosing three arrows used to mean a trip home for three
  arrows

**Farmers**

- A farmer moves at the same pace as the other field trades instead of strolling across
  its own field
- A farmer finishes picking a field before hauling. It used to set off for the chest the
  moment it could not see anything else to pick - usually a moment before the crop it had
  just lifted landed - and carry one turnip at a time

**Everyone**

- Field workers run to what is far and not to what is near, so a lumberjack no longer
  sprints three paces from one log to the next
- Residents use any chair or bench inside the settlement. Only seats within fifteen metres
  of the Frithstone counted, so everyone gathered at the stone to wait, talk and eat
- A chest marked private is private to everything. Gear fetching, meals and arrow restocks
  could still take from one - a hunter helped itself to a butcher's knife

**Performance**

- Two on-screen overlays no longer do layout work every frame while they have nothing to
  show, which mattered most with the inventory, a chest or the build menu open
- Building from settlement chests stays out of the way entirely until there is a
  settlement

## 0.1.7

Sailing with company.

- A boat with companions aboard sails like a boat again. A follower standing on a deck
  kept falling through the planking and being pushed back up out of the hull, and every
  push shoved the boat - a Karve with two companions aboard felt like it weighed a
  thousand tons and would barely steer. Followers now stay put where they were set down
  on the deck, and the boat only carries them
- A follower set down on a deck stands on the planking rather than a hand's width above it

## 0.1.6

No more freezing, and lumberjacks that fell trees.

- The game no longer freezes for a second every few seconds while residents work. A
  resident looking for a way to something it could not reach - a chest against a wall,
  the trunk of a tree, a rock - was allowed to search for as long as it liked, and every
  one of those searches stopped the game until it finished. A search now has a time
  limit, and a resident that runs out of it walks as close as it got and tries again
  from there
- Lumberjacks fell trees again instead of spending the day on stumps. Stumps always
  came before trees, and a forest never runs out of stumps. Now a lumberjack takes
  whichever is nearer, so the stump a felled tree leaves still gets cleared and the
  next tree gets its turn
- Stumps just outside a work area no longer pull lumberjacks away from the trees inside it
- A lumberjack carrying more than one axe uses the best of them, so an iron axe is not
  ignored because a flint one happened to be first in the pack

## 0.1.5

Playing together.

The first reports from shared worlds came in, and three things in them were bugs
rather than rough edges. All three were multiplayer only; nothing changes for a
world played alone.

- The host can hand out trades again while somebody else is in the settlement. A
  resident answers to whichever machine is looking after it at the moment, which is
  usually the nearest player's, and that machine had no way to recognise the host -
  Valheim never tells a joining player which character the host is playing. So
  every order the host gave a resident near another player was quietly turned away,
  and it came back the moment that player logged out
- The Frithstone panel no longer goes blank. After leaving to the main menu and
  coming back, pressing a resident's name could hide the tabs and everything under
  them, with the Back button hidden along with them, and the panel stayed that way
  until the game was restarted
- A resident standing in front of you is never listed as dead. One the panel could
  not confirm you may give orders to was shown among the dead and the missing, and
  opening it showed no trades to hand out

## 0.1.4

Villagers that get where they are going.

This one is almost entirely about movement and about the caretaker. A settlement
full of houses is a settlement full of doorways, and residents were losing
arguments with nearly all of them - standing at open gates, pressing on walls
beside doors, and declaring themselves stuck in the middle of their own village.

**Doorways**

- A resident walks through a door that is plainly open. The way a route is worked
  out could miss a doorway entirely if the doorway did not happen to line up with
  it, so a door standing wide open simply did not exist as far as the walking was
  concerned. Most of the village's "cannot get there" was this
- A door narrower than a resident thought it could fit through is measured at the
  door's own width now. Valheim's doorways are narrower than the room a resident
  asks for everywhere else, and only doorways are forgiven it
- A gate you are standing against is opened. One planned while a gate was open,
  then shut by the player, left a guard standing at it
- A door is noticed as far away as it can be seen. It was being found and then
  thrown away for being where it was found
- A door stops flapping. A route that crosses the same doorway more than once had
  residents opening and shutting it four times over before getting through; a door
  reopened straight after being shut now stays open. Never during a raid

**Getting unstuck**

- A resident walled into something gets out of it. The routine written to find the
  way out looked one step in eight directions and gave up if all eight were solid -
  which is exactly the state it exists for. It looks further now, and steps as far
  as the room actually is
- A resident stuck beside its own Frithstone counts as stuck. Being carried out was
  only ever offered to one a long way from home, and a builder that walks onto its
  own roof is ten metres from the stone and just as unable to reach a bed, a chest
  or a meal
- Being carried out twice in a row does not put it back beside the same trouble
- Nothing routes over a roof any more, including the short walk between two points
  of a route that was drawn properly

**The caretaker**

- Most tidying is settled without walking. A caretaker used to carry one armful at
  a time between chests it could see into from where it stood
- A round of chests is finished before anything else is started, and the chests come
  first rather than after the fires
- Chests are claimed by strength rather than by yes or no, so a thing goes to the
  chest that wants it most instead of the first that will have it
- A full chest no longer gets to say where something belongs
- What is not meat comes out of the meat chest first
- Cargo nothing will take back stops being owed back. Two caretakers were found
  standing at the same chest holding goods it would not accept, for as long as they
  held them
- One settlement, one board. Two caretakers were keeping separate ideas of the same
  settlement's stores

**Chests**

- A chest of your own: mark one private and no resident touches it
- A chest to empty your pockets into: mark one "take everything away" and the
  caretaker files whatever you drop in it
- Metals and ore have a kind of their own to sort by
- `inn.chests` lists every chest, what it is for, and how full it is

**The rest**

- A settler holding a tool fights with it. A guard with a stone axe and a follower
  with a fist weapon were both counted as empty-handed and swung fists
- A builder mends at the pace the game allows. Two builders on one house, or one
  practised one on its own, were swinging faster than a repair can land and healing
  nothing
- Pieces standing in water are left to the player. A builder would otherwise stand
  on a jetty over a piling it could never reach
- A plan that loses a piece comes down with it, and hold the key to cancel a site
  instead of building it
- A second builder with nothing in its hands goes and fetches instead of waiting
- The cook may put down what it has cooked, and walks to a chest that can take it
- Two boats do not share one berth, and a boat with one of your own aboard is never
  hauled home from under them
- The chest sorting window measures itself properly and is as tall as what is in it

## 0.1.3

A dedicated server no longer fills its console and falls over.

Nothing that draws is ticked on a machine with no screen. The trade route overlay was
asking Jotunn to build itself out of the vanilla map's texture, which a server does not
have, so it threw - once per frame, until the console filled and the server went down. A
map overlay nobody on a server could ever have looked at was taking the world with it.

The guard that should have caught it asked whether there was a minimap, and there is one
on a dedicated server: the object exists with nothing behind it. So the question is asked
properly now - Valheim's own dedicated flag, and the graphics device for the frames before
that exists - and the work areas overlay and the map pins stand down with it.

Two more layers, because the fault was the repetition rather than the throw. The overlay
checks for the texture it is actually built from, and if it throws anyway it says so once
and stops asking until the map is rebuilt.

Nothing else changed. Settlements, residents, roads and caravans are 0.1.2 exactly.

## 0.1.2

The Farmer, fields, and a settlement that can be run by more than one person.

- **The Farmer is handed out.** It sows, tends and harvests the fields you stake out,
  and it is no longer greyed. Only the Miner is still held back
- **Fields are staked, not fenced.** Put a Farm Marker down - the hammer's Innangard
  tab - and use it to say what grows there and how far the field reaches. The reach is
  drawn on the ground while the window is open, and a keep-out circle on the world map
  cuts a piece back out of it, which is how a field gets a shape that is not a circle.
  Fields are drawn on the world map under the circles that cut them, and where two
  overlap the ground goes to the nearer stake
- **A field rotates by itself.** It takes a crop and its seed turn and turn about, so it
  makes its own seed and never asks the settlement for more. A crop is only offered when
  its seed is in the chests and the biome will actually grow it
- **The mod's pieces have their own row in the hammer.** Frithstone, patrol point, farm
  marker and trade chest, above Misc, instead of being scattered through it
- **A settlement can have Leaders.** The Household screen on the Frithstone: a Leader has
  the founder's authority over everything the settlement does - trades, work, stores,
  land, trade routes - except giving or taking the title and handing the stone on, which
  stay with whoever raised it
- **A stranger cannot hit your residents.** A visitor could walk through a settlement and
  change nothing in it, but could kill its guards one at a time. A blow is now asked the
  same question an order is
- **Chest sorting is one press.** "What is this chest for" has eleven answers - nine kinds
  of thing, whatever it already holds, and a list you choose - instead of a search box and
  four hundred names. A chest may be set for more than one kind. And ticking a chest for
  one craft no longer locks every other craft out of it: the ticks decide where a craft
  looks first, not what it is allowed to open
- **Build from the settlement's chests** now counts every chest a craft may draw from
  rather than the first one it finds
- **A fisherman may swim to its boat.** Water is refused for every other errand, and it
  was refused for this one too, so a fisherman stood on the beach saying "no raft" with
  the raft in plain sight. The settlement's boat is also kept: one that drifts off with
  nobody aboard is brought back to its berth, and a berth is only chosen if somebody can
  actually get to it. Take the helm yourself and the boat stops being the settlement's
- **Hugin has six more things to say**: what keeps a resident from leaving, what stock
  targets are for, what a chest is for, the fisherman's rod and boat, the builder's plans,
  and what a Follower is. Each told the first time that part of the mod reaches you
- `inn.footprint` draws the settlement's own edge on the ground you are standing on
- Every trade gets better at what it actually does, and a blow in a fight is worth four
  swings at a tree

Fixed:

- The Obliterator counted as a chest. Residents were carrying the settlement's ore, coal
  and supper to the one object in the game built to delete them
- A caretaker put one thing in a chest and went back to picking things up. A round of
  chests is one errand now and ends when the pack is empty
- A farmer said it had no seed while the settlement held a hundred of them in another
  chest
- A caravan on an unbuilt line carried nothing, a carter could not open its own gate, and
  a load called back was counted as delivered
- A caravan's carters walked at their own craft's pace rather than the caravan's
- A settlement's name could change when its Frithstone was picked up and put back down
- A guard could not put anything down, and a hunter kept every hide it took
- Any `<Language>.json` in the `lang` folder is loaded now. It used to look for a fixed
  list of eight names, so a translation in any other language was silently ignored
- A finished stretch of road no longer draws stakes on the ground or says how far off it
  you are standing. The map overlay still shows the whole route
- "Cart" is gone from the texts. There is no waggon: the carriers walk with the load on
  their backs, and a finished road carries six times what a bare line does, which is what
  the word was standing in for

## 0.1.1

The store page, which I forgot to update with the rest of it.

- The page now says what this mod became. The first paragraph described a
  settlement where people work inside the walls and nothing ever leaves them, and
  the line under the mod's name said the same - both written before there were
  roads to build or caravans to send down them
- The two pictures that were missing with it: a road on the world map, green
  where it is built and yellow where it is only surveyed, and a work party out
  on one laying three lanes from a single pass of the hoe

Nothing in the mod itself has changed since 0.1.0.

## 0.1.0

Roads between your settlements, and caravans on them.

- **Every settlement has a name.** On its Frithstone, on its map pin, and across the top
  of its panel. Named the day it is founded and renamed from the Trade screen; the ones
  already standing in your world are named the first time you load it
- **Survey a way** between two settlements from the Trade screen. It looks for a line that
  keeps off the water, out of the mountains and off anything too steep to carry a load over,
  going the long way round where it has to, and it comes out of your gate rather than over
  your wall. It draws on the map, and on the ground near you with a stake at every stretch
- **Build the road yourself.** Hoe a path along the line and the stretch turns green;
  lay it in stone and it turns pale blue, which is worth more than green because a caravan
  runs quicker on it. A stretch built well off the line goes red: the road exists but a
  caravan still has to leave the route to use it
- **Muster a work party** and two or three residents walk out with you, one either side and
  one behind, laying whatever you lay where they are standing - so a pass with the hoe
  comes out three lanes wide. They fell the trees, break the stumps and clear the boulders
  standing on the line, which is most of what building a road through woodland is. They
  keep their crafts and go back to them when you send them home. Guards and cooks stay
  behind
- **Trade chest**: a reinforced chest with a column more room, and the loading dock for a
  caravan. What you put in it is what the next caravan carries, and what one brings in is
  waiting there. Nothing else in the mod touches it - not the Caretaker, not a meal, not
  your own building
- **Send a caravan** down a finished road. Two or three carriers walk out with the load
  on their backs at the pace the road allows - a bare line carries a sixth of what a
  finished road does, and where you are standing to watch them they are people
  walking a road rather than a number on a map. They arrive whether or not anybody is
  there to see it: the clock moves them, so a night's sleep moves them too. The goods turn
  up in the trade chest at the other end and the carriers come home
- The route says how far you are standing from it while you build, because a pixel of the
  map is twelve metres and the corridor that counts as road is two
- A road that has been built is kept. The line can be surveyed again any time; paving
  cannot be re-laid by pressing a button
- **Build and craft out of the settlement's chests** while you are standing in it. Every
  chest inside counts - the same chests the Caretaker works out of - so a workbench in the
  middle of a village reaches all of them and there is no round of opening chests before a
  build. Switch it off on the Settings screen if another mod already does this
- `inn.ground` says what the mod sees under your feet: paved, dirt path, or bare ground.
  Levelling flattens and paints nothing, so a stretch that looks like a road can be grass
  to everything here
- A resident that ends up a long way from its own settlement with nothing keeping it there
  is fetched home, whatever put it there
- Residents fetch an axe and a pick for a work party and put them back in the chest
  afterwards, unless it is their own craft's tool
- A forager no longer throws when it picks something with no player in the world, which
  would have been every pick on a dedicated server

## 0.0.91

Packaging only. The mod itself is 0.0.9 unchanged.

- The package asks for Jotunn 2.30.0 rather than 2.29.2. A fresh install through
  Thunderstore or r2modman was being handed the one Jotunn that empties every build menu
  in the game - the fault this release works around, and the one nobody should be sent to
  on purpose

## 0.0.9

The faults reported against 0.0.8, and the panel gone over. Update if you played 0.0.8:
the first thing on this list fills a disk.

- World copies are no longer written inside the world they are copying. A 1.0 save path
  ends in a separator, and the folder above a path that ends in a separator is that
  folder itself - so the copies went into the world's own save folder, and the next load
  copied the copies into the copy, and the one after that copied those. Players reported
  thirty gigabytes of it and folders nested deeper than Windows will delete. Two things
  stop it now and either would be enough alone. An Innangard folder left inside a world's
  save folder by an earlier version is safe to delete, and `inn.world.backups` says where
  the copies belong
- The Frithstone is in the hammer from the first day. Valheim hides a build piece until
  every material it costs has been handled, and the stone costs coins, a surtling core,
  amber and fine wood - so a new character's build menu had nothing of this mod anywhere
  in it, and the mod looked as though it had not installed. It still greys out until the
  materials are in the pack, and it is no longer announced as a new recipe every launch
- Guards and followers fight with their weapons instead of their fists. The pass that
  takes back gear a resident is no longer carrying was emptying the hand of gear it
  plainly was, thirty-eight times in one session
- The workarounds for Jotunn 2.29.2 stand down on 2.30.0, which is where they were always
  meant to stop. They did not, because the version they tested was a const the compiler
  had burned in at build time - the number this mod was built against rather than the one
  the player installed. That is why an updated Jotunn had empty custom build categories
- The alarm is for something getting inside the walls, or a guard going down. Any blow
  that landed anywhere the settlement covered used to stand the whole settlement to: a
  greyling chewing the outside of a palisade did it, and so did a wolf setting on a hunter
  two hundred metres out in the woods. It also announced itself once a swing rather than
  once an attack
- Enemies loose in the middle of a settlement count as being in it. The test asked for
  built cells and whatever they enclose, so a creature standing on the grass between two
  houses was, by that measure, outside the village it was attacking
- A resident's job is called a craft now, not a trade. Only the word changed
- The Settlers screen is a board of work rather than a list of names. Each card says what
  that resident is doing, its mood and what is in its way, so a settlement of eight is one
  look instead of eight clicks, and nothing has to be opened to see that something is wrong
- Changing what a resident does is two presses on that resident's own page, and neither of
  them is a mode to get out of afterwards. It was reported as not being possible at all
- The button across the top of the panel says what pressing it does. It used to state the
  settlement's condition, and state the one it was not in
- One work-area editor instead of two, and it opens where you can see it rather than half
  off the right-hand edge of the screen
- A stock row reads as a row: the minus no longer sits against the figure it cannot
  change, and the rows go two to a line
- `inn.overlay` turns the labels over a resident's head on and off without leaving the
  world. They were a config setting, and BepInEx reads a config file once
- A settlement has a name - on the stone, on its map pin and across the top of its panel.
  Sending a resident to another Frithstone offers those names rather than two sets of
  coordinates
- A caretaker walks past a chest that filled up while it was walking to it and gives the
  rest to the next chest that will have it, instead of abandoning the round, carrying
  everything back, and setting out again with the same load
- A chest standing in the settlement belongs to it without being taken in first. Claiming
  was opt-in and silent about it, so a Caretaker could report "no chest to draw from" while
  standing next to one. Untick every craft on a chest and it is refused, as before
- A resident asleep or sitting down is not stuck. The rescue reads the flags that mean
  being held on purpose instead of guessing from the body, so nobody is carried off a
  chair or out of a bed every sixty seconds
- The Builder keeps out of water it can stand up in, not only water it has to swim in
- A tree with something built on it is left standing. A ladder up a trunk or a platform in
  it came down with the tree, and whatever was on the platform came down too
- The Frithstone stops catching the cursor while a hammer is up. The box around it that
  makes Use easy to aim at sits on a layer Valheim's placement ray reads, so a ghost
  within about a metre and a half of the stone snapped to the surface of an invisible box
- The rename box takes the keyboard. It was opening in the same frame the panel behind it
  was being torn down, so the caret went nowhere and every key went to the game

## 0.0.8

Ready for Valheim 1.0. Update before you play it - 0.0.7 does not load on 1.0.

- Every part of the game this mod touches that 1.0 renamed or reshaped, followed:
  Hoverable's new hover offset (without which no settler could be loaded at all),
  VisEquipment's hand and hair items as hashes, Piece.SetCreator's platform account,
  Inventory.AddItem's two new flags, CookingStation.GetSlot's cheat flag, and the six
  container RPCs that all became their long names - which is why a resident's pack
  would not open
- World copies handle 1.0's chunked saves: one folder per copy, holding whatever the
  world says it is made of
- Works around two breaks in Jotunn 2.29.2 on 1.0, both of which stop the moment Jotunn
  is updated: its piece-table patch, which left every build menu in the game empty, and
  its console-command registration, which dropped all nine of this mod's commands
- Smoothbrain-Cooking no longer destroys dishes a settler collects: the food is lifted
  out of the slot into the pack instead of going through the station's hand-over
- Residents no longer flicker their tools in and out of their hands
- The Builder stays out of the water: nothing that has to be reached by swimming is
  chosen, anything that turns out to need it is left to the player, and a Builder that
  ends up in the sea walks to the nearest dry ground
- A plan the player has just laid out holds the Builder's hammer ahead of mending
- A build site's flag stays where it was planted instead of moving into the middle of
  the building on the next reload, and a plan that really did lose its stake gets the
  replacement outside its door rather than in the middle of the floor
- A Builder carrying materials gives up on a piece it cannot get to, instead of walking
  at it for the life of the plan
- A resident sits only while something is still asking it to, so a craft that finds work
  again stands up, and one left in a pose is taken out of it the way the game does rather
  than by writing animation flags at it - which is why one could sit half-reclined on a
  bed for minutes while the mod insisted it was standing
- Residents walk around colleagues who are standing still rather than pressing into them,
  and no longer collide with one another at all: two capsules wedged in a one-capsule
  doorway is a knot physics holds shut, and separation belongs to the steering that can
  take turns. They still collide with the world and with you
- A resident that cannot move is rescued whether or not it had somewhere to be, so one
  stuck while looking for its breakfast is carried out like any other
- Residents use the door: standing outside a wall no longer counts as being in reach of a
  chest inside it, so a caretaker walks in instead of unloading through the boards
- The Caretaker sorts by the load rather than by the item. It fills its pack at the intake
  chest with everything that has a home, remembers where each part belongs, and delivers
  nearest chest first - one trip per destination instead of one trip per kind
- A chest you marked for wood now gives up everything that is not wood. The mark used to
  decide only what could be carried in; it now also says what does not belong
- The Builder's Hammer captures a blueprint itself: look at a building, press B, name it.
  Writing one down no longer means opening the console, and the key is on the hint bar
- The Builder's Hammer has vanilla's repair entry, which is also the one selection that
  draws no building on the cursor
- The Builder fills its pack rather than carrying one stack of each kind home, and looks
  at a stuck plan again sooner
- The Builder raises everything within reach before taking a step, instead of walking
  once per piece, and a piece takes half as long to raise. A cabin that was most walking
  is now mostly building
- A blueprint captured with the hammer already in hand appears in it at once, rather than
  after the hammer is dropped and picked up again
- The eight blueprints by other builders are gone. Only the mod's own three-bed cabin
  ships now; yours are made with the hammer
- A settler killed out at its work no longer breaks the frith; it comes back, tells a
  guard where it happened, and the watch goes out to look
- Hunters may take game a short walk outside their grounds, and say why they took nothing
- The panel's map screen closes with Escape as well as with Back
- The work-area box on the world map is Valheim's own wood panel now, not the flat grey
  IMGUI box it used to be. It was the last screen in the mod not built like the rest

## 0.0.7

- BepInExPack listed as a dependency in its own right, not only through Jotunn
- Patrol Point is a standing torch that burns without fuel; Farm Marker is a signpost
- `inn.frith.adopt`: residents whose Frithstone is gone join the nearest one of yours
- Guards answer a monster of the game's own hostile factions before it has noticed anyone
- Settings and Settlers screens no longer fault on the first world opened after a return to the menu
- A raft held afloat on a shelf is backed out, shoved, then lifted off; the helmsman no longer runs on the spot
- A calm monster inside the wall is the guards' business, not a broken frith
- Eight more blueprints in the Builder's Hammer, from other builders and credited to them

## 0.0.6

First public release.

- Frithstone, recruitment, beds, settlement chests and the management panel
- Crafts: Lumberjack, Forager, Hunter, Fisherman, Cook, Caretaker, Builder, Guard,
  Follower. Farmer and Miner are present but not yet offered.
- Work areas drawn on the map, stock targets, chest filters
- Needs, mood, traits, skills, chatter
- Guards, alarm, frith doctrine, retreat and gear from the chests
- Builder's Hammer, blueprints, and one plan to start with: a three-bed cabin
- World copies taken before and after each session
