<!-- nexus:center -->
# Innangard

*Beyond the wall lies chaos. Within it, your people.*

![Halstad from above: the palisade, the houses, the tower and the fields inside the wall.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986470-49756115.png)

<!-- /nexus:center -->
Innangard turns your base into a settlement. You raise a Frithstone and wall it in, then take
in villagers and give each one a trade. From then on they keep the place running: they
fell, fish, hunt, farm, cook, smith and build, and they sleep, eat, talk and hold the
wall when the night comes. It all keeps going while you are out exploring.

You can then join your settlements with roads. Survey a road, build it with a work party
at your side, and send caravans down it. The caravans arrive whether or not you are
there to watch.

**Clans are live.** Found a clan at your Frithstone, take in other players as Hersir,
Bóndi and Hirðmaðr, and bring every member's village under one banner. Make alliances,
call your clan to defend a village, and - on servers that switch it on - go to war and
raid the enemy's villages while their guards fight back. See **Clans** below.

*innangardr* is Old Norse for "within the enclosure": the ordered world inside the
fence, as opposed to *utangardr*, the wild beyond.

**Come and say hello on [Discord](https://discord.gg/U9YQQK3BUv).** Show off your
settlement, ask when something puzzles you, report a bug and see it fixed, and hear what
is coming next before anyone else.

**Hi, I'm Yololo.** Innangard is a one-person project that I build in my evenings and
weekends, and it's free - it always will be. No part of it will ever sit behind a paywall,
whatever happens.

But every hour I put into it is an hour I have to find somewhere. If your villagers have
made you smile, or saved you a few trips to the chests, a coffee's worth on
**[Patreon](https://www.patreon.com/cw/Yololo)** goes straight back into the mod: more
crafts, fewer bugs, quicker fixes. It honestly makes the difference between "someday" and
"next week".

And if that's not for you, that's completely fine. Playing it, leaving a comment or sending
a bug report helps more than you'd think. Thank you for being here.

## New in 0.4.0

- **Trade by sea.** Moor a Karve, a Longship or a Drakkar by your Frithstone, chart a sea
  way to another settlement on the coast, and send the ship. It carries far more than a
  caravan, needs no road, and sails itself: you can watch it leave harbour under sail, and
  it keeps sailing while nobody is near
- **Ship goods across your whole network.** An inland village can send to a far harbour:
  by road to the nearest port, by ship across, and on by road from there. Every settlement
  on the way hands the load to its next carrier by itself
- **Archers stop flickering on the spot** when they have no shot at something close by.
  They circle round for a clear shot or hold outside its reach instead of stepping in and
  out
- **Residents are no longer charged for a night nobody was there for.** When everyone spent
  the night away from the village, the residents woke the next morning "short of sleep"
  and "without supper" for a night they never lived

And from 0.3.9:

- **Watch posts.** Place a Watch Post on a tower or a wall walk, and a guard with a bow
  stands it for the whole shift and shoots what it can see from up there. It does not
  climb down to chase, and it holds the tower during raids too. One guard to each post;
  the post needs stairs or a ramp up to it
- **Archers no longer flicker in place** when an enemy gets close and the shot is blocked.
  They back away properly and turn to shoot once they have the distance
- **The clan event list is translated**, and the warnings about clan tokens at game start
  are gone

And from 0.3.8:

- **Innangard in 13 more languages.** Turkish, Spanish, French, German, Italian,
  Brazilian Portuguese, Russian, Polish, Ukrainian, Simplified and Traditional Chinese,
  Japanese and Korean, following the language you set in Valheim
- **Residents sleep through a skipped night**, on dedicated servers too and when you
  sleep in the afternoon, so they no longer lose morale for a night they never had
- **Guards go out through the gate** to meet an enemy on the other side of the wall,
  instead of standing at the palisade

And from 0.3.6:

- **Clans are live.** Found a clan, bring your friends' villages into it, make alliances
  and, on servers that allow it, wage war and raid each other's villages. Everything is
  in the **Clans** section below
- **Guards defend against clan raids.** Settlement guards fight raiders however far the
  village is from the clans' Frithstones, and the defending clan sees
  "Fjellby is under attack!" (with the village's own name) when a raid starts
- **The Caretaker stops shuffling chests.** Items in a chest set to "What it already holds"
  only move to a chest that asks for them, never to a merely empty one
- **Fighters do not freeze at the water's edge.** Residents fight a leech within reach
  from the shore, and archers keep their distance and their bows
- **Followers keep formation**, and carried loads are never worn, so "Take better gear
  from chests" switched off stays off

And from 0.3.5 and 0.3.4:

- **Work areas on no-map worlds.** The Frithstone opens Valheim's own map for drawing
  work areas, even when the world has the map turned off
- **Chest sorting sees flour, eggs and the odd items.** Barley flour, oat flour, eggs,
  keys, saddles, dragon tears, ancient seeds and barrel hoops were ignored by sorting and
  are sorted now. Flour, bread dough, the uncooked dishes and eggs go to a Food chest

And from 0.3.3:

- **Combat movement is steadier.** Residents no longer keep refreshing a chase path when
  a moving enemy barely shifts position. Melee fighters hold the shore when a target is
  swimming, and swimmers head for dry ground before resuming combat
- **Path searches share their work across frames.** Expensive neighbor and doorway checks
  yield within a frame budget, reducing hitches while residents find routes through
  crowded or built up settlements
- **Fishermen put the rod away between casts.** The fishing rod stays equipped while the
  line is cast and is released when that action ends
- **Caretakers can unload fish left in a resident's pack.** Raw fish is now eligible for
  the normal storage run after a resident changes trades

And from 0.3.1 and 0.3.0, if you are coming from further back:

- **The Smith is handed out.** It makes things to the Stock tab's targets, mends what
  wears out, keeps the archers in arrows and dresses bare residents
- **Residents get where they are going.** They climb stacked step ladders, go out
  through the gate on errands beyond the wall and open the doors that are in their way.
  They also reach chests on terraces that used to be out of their range
- **Gear by trade.** Axes and picks go to the trades that swing them, bows and light
  armour to hunters, and the heaviest and best to guards and followers
- **Lighter.** With ten residents, the mod's share of a frame fell from about eleven
  milliseconds to about one

Everything else is in the changelog. **Everyone on a server needs the same version,**
and back up your world before updating.

## What it does

- **A real settlement.** Your settlement is the area inside the walls you build. The
  Frithstone is its heart, and Hugin explains the rest as you go
- **Twelve trades.** Lumberjack, Forager, Hunter, Fisherman, Farmer, Cook, Caretaker,
  Smith, Builder, Guard, Follower and Miner, each with its own skill that grows with
  the work
- **People, not workers.** Residents have traits, moods and the reasons behind them.
  They keep beds, meals and friendships, and an unhappy resident will walk out in the
  end
- **Work you draw on the map.** You mark allowed and forbidden areas per trade and
  stake out fields. You set stock targets, and the settlement works up to them and stops
- **Chests that know what they are for.** The Caretaker sorts everything into place,
  and what the chests hold counts towards what you build
- **A settlement that defends itself.** Guards patrol and answer raids. When a guard
  falls, everyone who can hold a weapon fights for their own ground
- **Builders and blueprints.** Write down any building with one key press, lay it out
  as a plan, and the Builder raises it piece by piece
- **Roads and caravans.** Your villages are linked by roads you build yourself, and
  carriers walk the goods between them
- **Followers.** A Follower travels with you, boards ships and goes through portals and
  into dungeons
- **Clans.** Players band together under a Jarl with Viking ranks, link their villages,
  make alliances, answer each other's calls for help and, where the server allows it,
  wage war and raid
- **Built for servers.** Leaders and visitors are separate roles, settings are synchronised
  and world backups are taken every session

## Screenshots

<!-- nexus:center -->
![Raise the Frithstone, and Hugin comes down to explain the frith.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1788908314-1868073358.png)

*Raise the Frithstone, and Hugin comes down to explain the frith.*

![Every trade, everyone holding it, and what each of them is doing right now.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986484-1141627902.png)

*Every trade, everyone holding it, and what each of them is doing right now.*

![A resident's own page: what it is doing, how it feels and why, its skills and how it fights.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986488-260690555.png)

*A resident's own page: what it is doing, how it feels and why, its skills and how it fights.*

![Residents climb ladders now, up to the floors that used to be out of their reach.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986509-289283318.png)

*Residents climb ladders now, up to the floors that used to be out of their reach.*

![A chest that knows what it is for: green frames belong, red ones the Caretaker will carry away.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986478-2102117602.png)

*A chest that knows what it is for: green frames belong, red ones the Caretaker will carry away.*

![Stock targets: the settlement works up to a figure and stops.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986490-287852836.png)

*Stock targets: the settlement works up to a figure and stops.*

![Work areas on the world map, allowed in yellow and forbidden in red.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1789044976-42763647.png)

*Work areas on the world map, allowed in yellow and forbidden in red.*

![A Farm Marker's reach drawn on the ground: this field grows onions.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986508-340759419.png)

*A Farm Marker's reach drawn on the ground: this field grows onions.*

![What a fisherman carries home.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1788908538-463233431.png)

*What a fisherman carries home.*

![A blueprint laid out as a plan; the Builder raises it piece by piece.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1788908642-404902871.png)

*A blueprint laid out as a plan; the Builder raises it piece by piece.*

![A work party out on the road - three lanes from one pass of the hoe.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1789069762-1806917009.png)

*A work party out on the road - three lanes from one pass of the hoe.*

![A road on the world map: green where it is built, yellow where it is only surveyed.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1789069759-892510220.png)

*A road on the world map: green where it is built, yellow where it is only surveyed.*

![The Trade screen: the road to Vinvik built end to end, a caravan ready to send, and a work party to muster.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986496-522929963.png)

*The Trade screen: the road to Vinvik built end to end, a caravan ready to send, and a work party to muster.*

![The Guide tab explains the mod one topic at a time.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986507-713672294.png)

*The Guide tab explains the mod one topic at a time.*

![The panel's settings. Every other setting is in game too: Esc, then Innangard.](https://staticdelivery.nexusmods.com/mods/3667/images/3607/3607-1791986498-1200278481.png)

*The panel's settings. Every other setting is in game too: Esc, then Innangard.*
<!-- /nexus:center -->

## Requirements

- Valheim 1.0 or later. 0.0.7 is the last build for the patches before 1.0
- [BepInExPack Valheim](https://thunderstore.io/c/valheim/p/denikson/BepInExPack_Valheim/)
- [Jotunn](https://thunderstore.io/c/valheim/p/ValheimModding/Jotunn/) 2.30.0 or newer

## Installation

- **Mod manager** (r2modman, Thunderstore Mod Manager, Vortex): install this mod and let
  the manager bring BepInEx and Jotunn.
- **By hand**: install BepInEx and Jotunn, then unzip this archive into the game's
  folder. `BepInEx/plugins/Innangard/Innangard.dll` should end up beside its `lang` and
  `blueprints` folders.
- **Servers**: install the same files on the server. Everyone needs the same version, down
  to the patch number. The mod refuses to connect two different builds, because they
  would read each other's settlements wrongly.
- **Never open your world without the mod.** Valheim deletes anything it does not
  recognise, so a single launch without Innangard erases every stone and every resident.
  The mod keeps copies of the world from before and after each session, five by default,
  and `inn.world.backups` lists them.

## Getting started

1. **Raise the Frithstone.** It is in the hammer's Misc tab and costs 20 stone, a surtling
   core and 5 fine wood. Hugin comes down to explain the frith.
2. **Wall it in and leave a gate.** The settlement's inside and outside follow the walls
   you build, and so do its people.
3. **Recruit from the panel** that opens on the stone. The first two residents cost 20
   coins each, then 30, 50 and 100, and 200 for everyone after that.
4. **Put down a bed for each resident and some chests.** Residents store their work in the
   chests and eat from them.
5. **Hand out the trades.** The panel's **Guide** tab explains the mod one topic at a time.

## The trades

- **Lumberjack** fells trees, clears the logs and stumps and hauls the wood home. It can
  be set to replant
- **Forager** gathers berries, mushrooms, thistle and seeds
- **Hunter** hunts the animals you allow, loots its kills and brings back meat and hides.
  It leaves tame animals, bosses and raiders alone
- **Fisherman** takes a boat out of the settlement's harbour and brings the catch home.
  It needs a rod and a boat moored at the settlement
- **Farmer** sows, tends and harvests the fields you stake out, and grows its own seed
- **Cook** cooks the raw food from the chests at the stations and the cauldron. It
  prefers mixed dishes, which are worth more to morale
- **Caretaker** keeps the chests sorted, picks up what is lying on the floor and keeps
  the fires and furnaces fed
- **Smith** crafts at the settlement's stations, from the founder's recipes, up to the
  Stock tab's targets. It mends broken tools, keeps arrows in the chests and dresses
  bare residents
- **Builder** repairs damage and raises the plans you lay out
- **Guard** watches the ground around the stone, walks the patrol points you plant and
  answers attacks. A guard with a bow keeps a Watch Post you place on a tower. Off shift,
  it rests
- **Follower** leaves the settlement to travel with you and fights at your side. You can
  set it to Defensive, Aggressive or Passive
- **Miner** is greyed out until it has been watched through a full session. See Known
  issues

## Running the settlement

Use the Frithstone to open the panel. **Settlers** shows every trade, who holds it and
what each of them is doing right now. Press a name to open that resident's page, which
shows its mood and the reasons for it, its gear, its skills and its orders. **Stock**
holds the targets the settlement works up to. Food below its own target is not eaten.
**Construction**, **Trade** and **Household** cover plans, roads and who may give orders.
Every setting can also be changed in game: Esc, then Innangard.

**Work areas are drawn on the world map.** Allowed areas are yellow circles and forbidden
areas are red. Each circle has its own size and trade, so a small hunting ground and a
wide felling site can sit side by side while the bog between them is kept out.

**Chests.** Shift+Use on a chest opens its sorting window, which asks one question: what
is this chest for? Looking at a chest shows its answer. Green slot frames mark what
belongs there and red ones mark what the Caretaker will carry away. Every item's tooltip
says where it belongs. While you stand in the settlement, what its chests hold counts
towards what you build.

**Fields are staked, not fenced.** A Farm Marker, in the hammer's Innangard tab, says
what grows there and how far the field reaches. The field alternates the crop with its
own seed, so it never needs seed from the settlement.

## Roads and caravans

Survey a road to another of your settlements from the Trade screen. The line keeps off
the water, out of the mountains and off slopes too steep to carry a load over, and it
leaves through your gate. Then you build it. A stretch turns green when you hoe it and
pale blue when you lay it in stone.

**Muster a work party** and two or three residents walk out with you, laying whatever you
lay where they stand. One pass of the hoe comes out three lanes wide, and they clear the
trees, stumps and boulders on the line.

**Send a caravan** between two trade chests. The carriers walk at the pace the road
allows, and a finished road carries six times what a bare line does. They arrive whether
or not you are there, even while you sleep. Nothing is bought or sold: both villages are
yours, so the caravans only carry goods between them.

**Trade by sea.** A settlement on the coast can send a ship instead. Moor a Karve, a
Longship or a Drakkar near the Frithstone - not a raft - and chart a sea way to another
coastal settlement from the Trade screen: the line keeps to water deep enough for a keel
and away from the shore. Then send the ship. It loads from the trade chest, sails the
line, unloads into the far trade chest and comes home to the berth it left. A ship carries
thirty goods for every slot of its hold, so even a Karve carries what a caravan does on a
finished road. It sails on whether or not anybody is near, and a ship on a voyage cannot
be taken by its helm until it is home; call it back from the Frithstone instead.

**Ship goods further afield.** Roads and sea ways are one network. From the Trade screen,
send goods to any settlement the network reaches: the mod picks the quickest chain of
roads and sea ways, and every settlement on the way passes the load on to its next
carrier - the caravan on the next road, or a free ship in its harbour - as soon as one is
free. Only the far end needs a trade chest.

## Daily life and defence

Residents sleep at night and eat breakfast and supper from the chests, sitting down to
eat when there is a seat. They talk, stroll and take their spare time. Happiness runs from
0 to 100, and the panel says why: slept well, missed supper, the walls were broken, a
friend was lost. Each resident has one of eight traits, from Hardy to Solitary, and gets
better at the work it does.

Guards answer whatever comes within their radius and do not chase far. The alarm sounds
when a raid begins. The fight is the guards' until one of them falls, and then everyone
who can hold a weapon defends their own ground. The wounded fall back until healed, and
the loot is gathered in afterwards. A resident who dies comes back to the stone and goes
to fetch its gear from its grave.

## Clans

A clan is a group of players and their villages under one Jarl. Everything happens in
the Frithstone panel's **Clan** tab, which has four groups: Members, Villages, Diplomacy
and Defense. Joining a clan never hands over your village: ownership, your residents and
your own Leaders stay yours.

**Founding and joining.** Name your clan in the Members group and you are its Jarl. Others
join by accepting an invitation, or by applying and being approved by the Jarl. A player
belongs to one clan at a time.

**Ranks.**

- **Jarl** leads the clan: invites and removes members, gives every rank, links villages,
  makes alliances and war, and names a successor, who becomes Jarl when they accept
- **Hersir** helps run it: invites and removes members, gives Bóndi and Hirðmaðr, and
  helps with clan trade and defense
- **Bóndi** looks after a village day to day, in the villages where its owner has made
  them Steward
- **Hirðmaðr** is a member: sees the clan, joins its calls for help and can volunteer for
  war

**Villages.** A village owner asks to join from the Villages group, and the Jarl approves.
In the owner's Household tab, a member can be made **Steward** of that one village, which
lets their clan rank manage it there and nowhere else. Leaving the clan, or being removed,
takes your villages out with you.

**Diplomacy.** Jarls offer and accept alliances. Allies can open trade between their
villages, but an alliance never opens anyone's chests or buildings.

**Defense calls.** When a village is threatened, its leaders call the clan and its allies
for help. Anyone can volunteer; the call lasts fifteen minutes.

**War and raids.** Clan war is **off unless the server admin turns it on**
(`inn.clan.pvp on`), and can be limited to set hours. Both Jarls must agree to a war, and
every member decides for themselves whether to fight: joining a clan never puts you in
PvP. During a war the Jarl can launch a **raid** on one enemy village, when both sides
have volunteers online and a defender is at that village. For fifteen minutes, raiders and
defenders can fight within 65 metres of it, whatever their own PvP switch says. The
village's guards fight the raiders, and every member of the defending clan sees
**"Fjellby is under attack!"** (with the village's own name). Raids are fights between volunteers: no buildings are
broken and no chests are looted. Ending a war starts a 24-hour ceasefire.

## Builder and blueprints

Hold the Builder's Hammer, look at a building and press **B**. Name it, and it is
written down as a blueprint and offered by the hammer straight away. Lay the plan
anywhere and the Builder raises it from the ground up, paying for every piece from the
settlement's stores before it goes up. The mod comes with one three-bed cabin, and it
can read a PlanBuild library you already have.

<!-- nexus:spoiler Console commands -->
Press F5 for the console. None of these is a cheat.

- `inn.bp.capture <name> [radius]` writes the building you are looking at down as a blueprint
- `inn.bp.place <name>` lays a blueprint out in front of you
- `inn.bp.mend` re-plans whatever is missing from the plan-built building you are in
- `inn.frith.adopt [radius]` makes residents whose stone is gone join the nearest one
- `inn.follower.home` sends followers left out in the world back to the stone
- `inn.world.backups` lists the world copies
- `inn.perf [seconds]` measures where the mod's frame time goes
- `inn.clan.pvp <on|off|status>` turns clan war and raids on or off for the server (admin)
- `inn.clan.pvp hours <start> <end>` limits raids to those UTC hours; `hours off` lifts it (admin)
- `inn.clan.recover <settlement-code>` restores a clan whose root Frithstone was lost, from one of its villages (admin)
<!-- /nexus:spoiler -->

Settings are in `BepInEx/config/com.yololo.innangard.cfg`, and most of them are also in
game. The texts are in `lang/English.json` beside the dll if you want to translate them.

## Known issues

- **Update Jotunn to 2.30.0 or newer.** 2.29.2 empties every build menu on Valheim 1.0.
  Innangard works around that, but tabs added by other mods go missing until you update
- **The Miner is greyed out.** It has not been watched through a full session yet.
  `Work/OfferUnfinishedCrafts` hands it out anyway. If you try it, keep the verbose log on
  and say what happened
- **The Smith is new.** If it does something odd in a busy settlement, report it on
  Discord with the log
- **The Farmer does not hoe.** It only sows ground you have cultivated yourself
- **Multiplayer has had little testing** with more than one player at a time
- **Clans are new.** Clan records live on the founding Frithstone; a Jarl or member far
  from it may need a moment, or a walk closer, before a change shows. Report anything odd
  on Discord with the log

## What comes next

Barter and prices, so caravans can trade as well as carry. Roads between different
players' settlements. Sea routes and harbours. Caravans that can be raided, with guards
to protect them. Bridges. The Miner, and titles below Leader.

*Innangard is an unofficial fan mod and is not affiliated with Iron Gate.*
